# Semantic Quality Report

## 1. Run Metadata

```json
{
  "actual_calls": 68,
  "actual_tokens": 194761,
  "batch_size": 5,
  "cache_hit_tokens": 65152,
  "cache_miss_tokens": 0,
  "concurrency": 3,
  "db_path": "/Users/wangrundong/work/infomation-center/content_inbox/data/content_inbox.sqlite3",
  "dry_run": true,
  "duration_seconds": 429.014,
  "evaluation_db_path": "/var/folders/f_/12__g2851hv407x2tv3xbx580000gn/T/content_inbox_semantic_eval__twz32o6.sqlite3",
  "finished_at": "2026-05-17T03:51:18.114123+00:00",
  "git_commit": "e7d51ad7bd188d0d986f52ec19a05ce2cbab9f41",
  "include_archived": false,
  "items_sampled": 50,
  "live": true,
  "max_calls": 120,
  "max_candidates": 5,
  "max_items": 50,
  "model": "deepseek-v4-flash",
  "recall_strategy": "lexical/entity/time/source hybrid",
  "run_id": "semantic_eval_20260517_034409_087022",
  "sample_mode": "event_hotspots",
  "source_filter": null,
  "source_url_prefix": "api.xgo.ing",
  "stage_budget_profile": "relation_heavy",
  "stage_budgets": {
    "cluster_card_patch": 17500,
    "item_card": 80000,
    "item_cluster_relation": 60000,
    "item_relation": 85000,
    "source_profile": 7500
  },
  "started_at": "2026-05-17T03:44:09.087022+00:00",
  "strong_model": null,
  "token_budget": 250000,
  "vector_index": false,
  "warnings": [],
  "write_real_db": false
}
```

## 2. Source Scope

```json
{
  "matched_source_count": 151,
  "source_filter": null,
  "source_url_prefix": "api.xgo.ing",
  "sources": [
    {
      "feed_url": "https://api.xgo.ing/rss/user/0277b0bbefd54df7bc6b7880122da8f7",
      "item_count": 26,
      "latest_item_time": "2026-05-17T02:16:56+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-orange-ai-oran-ge",
      "source_name": "orange.ai(@oran_ge)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/05f1492e43514dc3862a076d3697c390",
      "item_count": 25,
      "latest_item_time": "2026-05-15T19:17:19+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-nvidia-ai-nvidiaai",
      "source_name": "NVIDIA AI(@NVIDIAAI)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/74e542992cf7441390c708f5601071d4",
      "item_count": 11,
      "latest_item_time": "2026-05-12T23:47:03+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-imxiaohu",
      "source_name": "小互(@imxiaohu)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/082097117b4543e9a741cd2580f936d3",
      "item_count": 11,
      "latest_item_time": "2026-04-24T07:24:53+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-junyang-lin-justinlin610",
      "source_name": "Junyang Lin(@JustinLin610)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/179bcc4b8e5d4274b6e9e935f9fd4434",
      "item_count": 10,
      "latest_item_time": "2026-05-06T19:30:36+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-aadit-sheth-aaditsh",
      "source_name": "Aadit Sheth(@aaditsh)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/22af005b21ec45b1a4503acca777b7f0",
      "item_count": 10,
      "latest_item_time": "2026-03-10T20:50:07+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-ai-sdk-aisdk",
      "source_name": "AI SDK(@aisdk)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/08b5488b20bc437c8bfc317a52e5c26d",
      "item_count": 10,
      "latest_item_time": "2026-04-30T16:21:35+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-andrew-ng-andrewyng",
      "source_name": "Andrew Ng(@AndrewYNg)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/f7992687b8d74b14bf2341eb3a0a5ec4",
      "item_count": 10,
      "latest_item_time": "2026-05-05T17:02:24+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-chatgpt-chatgptapp",
      "source_name": "ChatGPT(@ChatGPTapp)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/0be252fedbe84ad7bea21be44b18da89",
      "item_count": 10,
      "latest_item_time": "2026-04-30T19:00:00+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-dify-dify-ai",
      "source_name": "Dify(@dify_ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/1897eed387064dfab443764d6da50bc6",
      "item_count": 10,
      "latest_item_time": "2026-05-07T14:00:37+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-elevenlabs-elevenlabsio",
      "source_name": "ElevenLabs(@elevenlabsio)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/931d6e88e067496cac6bf23f69d60f33",
      "item_count": 10,
      "latest_item_time": "2026-05-10T16:39:05+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-elvis-omarsar0",
      "source_name": "elvis(@omarsar0)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/cb6169815e2e447e8e6148a4af3f9686",
      "item_count": 10,
      "latest_item_time": "2026-05-01T17:33:11+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-geoffrey-hinton-geoffreyhinton",
      "source_name": "Geoffrey Hinton(@geoffreyhinton)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/771b32075fe54a83bdb6966de9647b4f",
      "item_count": 10,
      "latest_item_time": "2026-02-18T22:04:39+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-groq-inc-groqinc",
      "source_name": "Groq Inc(@GroqInc)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/e8750659b8154dbfa0489f451e044af1",
      "item_count": 10,
      "latest_item_time": "2026-05-10T19:32:11+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-guillermo-rauch-rauchg",
      "source_name": "Guillermo Rauch(@rauchg)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/58894bf2934a426ca833c682da2bc810",
      "item_count": 10,
      "latest_item_time": "2026-05-11T17:00:14+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-justin-welsh-thejustinwelsh",
      "source_name": "Justin Welsh(@thejustinwelsh)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/db648e4d4eae4822aa0d34f0faef7ad2",
      "item_count": 10,
      "latest_item_time": "2026-04-30T06:49:02+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-lovartai-lovart-ai",
      "source_name": "LovartAI(@lovart_ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/221a88341acb475db221a12fed8208d0",
      "item_count": 10,
      "latest_item_time": "2026-04-30T17:30:36+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-notebooklm-notebooklm",
      "source_name": "NotebookLM(@NotebookLM)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/0c0856a69f9f49cf961018c32a0b0049",
      "item_count": 10,
      "latest_item_time": "2026-05-07T20:08:51+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-openai-openai",
      "source_name": "OpenAI(@OpenAI)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/17687b1051204b2dbaed4ea4c9178f28",
      "item_count": 10,
      "latest_item_time": "2026-05-02T04:37:44+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-poe-poe-platform",
      "source_name": "Poe(@poe_platform)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/4838204097ed422eac24ad48e68dc3ff",
      "item_count": 10,
      "latest_item_time": "2026-05-07T21:07:12+00:00",
      "sampled_item_count": 4,
      "source_id": "socialmedia-ray-dalio-raydalio",
      "source_name": "Ray Dalio(@RayDalio)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/12eba9c3db4940c5ab2a72bd00f9ff2c",
      "item_count": 10,
      "latest_item_time": "2026-04-30T14:02:05+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-replicate-replicate",
      "source_name": "Replicate(@replicate)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/3953aa71e87a422eb9d7bf6ff1c7c43e",
      "item_count": 10,
      "latest_item_time": "2026-05-05T16:39:00+00:00",
      "sampled_item_count": 2,
      "source_id": "socialmedia-xai-xai",
      "source_name": "xAI(@xai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/f3fedf817599470dbf8d8d11f0872475",
      "item_count": 9,
      "latest_item_time": "2026-05-08T18:00:28+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-a16z-a16z",
      "source_name": "a16z(@a16z)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/3042b6f912b24f64982cc23f7bd59681",
      "item_count": 9,
      "latest_item_time": "2026-04-28T15:15:29+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-adam-d-angelo-adamdangelo",
      "source_name": "Adam D'Angelo(@adamdangelo)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/0e3ebaf288014c45b0d24b71fe37312b",
      "item_count": 9,
      "latest_item_time": "2026-04-27T11:31:05+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-ai-breakfast-aibreakfast",
      "source_name": "AI Breakfast(@AiBreakfast)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/7d19a619a1cc4a9896129211269d2c85",
      "item_count": 9,
      "latest_item_time": "2026-05-12T18:36:29+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-ai-engineer-aidotengineer",
      "source_name": "AI Engineer(@aiDotEngineer)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/aa74321087f9405a872fd9a76b743bf8",
      "item_count": 9,
      "latest_item_time": "2026-05-15T08:22:59+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-ai-will-financeyf5",
      "source_name": "AI Will(@FinanceYF5)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/341f7b9f8d9b477e8bb200caa7f32c6e",
      "item_count": 9,
      "latest_item_time": "2026-05-13T12:46:05+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-ak-akhaliq",
      "source_name": "AK(@_akhaliq)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/3434c0d56ee0446f991fb6af42bfac4b",
      "item_count": 9,
      "latest_item_time": "2026-05-08T00:50:20+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-akshay-kothari-akothari",
      "source_name": "Akshay Kothari(@akothari)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/524525de0d69407b80f0a7d891fdc8df",
      "item_count": 9,
      "latest_item_time": "2026-04-20T17:19:14+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-alex-albert-alexalbert",
      "source_name": "Alex Albert(@alexalbert__)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/edf707b5c0b248579085f66d7a3c5524",
      "item_count": 9,
      "latest_item_time": "2026-04-30T17:43:06+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-andrej-karpathy-karpathy",
      "source_name": "Andrej Karpathy(@karpathy)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/fc28a211471b496682feff329ec616e5",
      "item_count": 9,
      "latest_item_time": "2026-05-07T17:08:35+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-anthropic-anthropicai",
      "source_name": "Anthropic(@AnthropicAI)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/5f13b32b124a41cfb659f903a84032b1",
      "item_count": 9,
      "latest_item_time": "2026-05-04T10:49:37+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-anton-osika-eu-acc-antonosika",
      "source_name": "Anton Osika – eu/acc(@antonosika)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/59e6b63ae9684d11be0ae13d9e7420f2",
      "item_count": 9,
      "latest_item_time": "2026-05-06T14:33:15+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-aravind-srinivas-aravsrinivas",
      "source_name": "Aravind Srinivas(@AravSrinivas)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/e153fdd077df458b8298d975c060dcc3",
      "item_count": 9,
      "latest_item_time": "2026-05-04T23:25:51+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-augment-code-augmentcode",
      "source_name": "Augment Code(@augmentcode)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/760ab7cd9708452c9ce1f9144b92a430",
      "item_count": 9,
      "latest_item_time": "2026-04-30T23:30:36+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-bolt-new-boltdotnew",
      "source_name": "bolt.new(@boltdotnew)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/b8d7530f0b294405825013bbc1cc198f",
      "item_count": 9,
      "latest_item_time": "2026-05-06T00:48:01+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-browser-use-browser-use",
      "source_name": "Browser Use(@browser_use)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/66a6b39ddcfa42e39621e0ab293c1bdd",
      "item_count": 9,
      "latest_item_time": "2026-04-30T21:29:34+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-cat-catwu",
      "source_name": "cat(@_catwu)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/3877c31cdb554cffb750b3b683c98c4d",
      "item_count": 9,
      "latest_item_time": "2026-04-30T21:37:28+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-character-ai-character-ai",
      "source_name": "Character.AI(@character_ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/4cc14cbd15c74e189d537c415369e1a7",
      "item_count": 9,
      "latest_item_time": "2026-05-05T17:00:56+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-cognition-cognition-labs",
      "source_name": "Cognition(@cognition_labs)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/462aa134ed914f98b3491680ad9b36ed",
      "item_count": 9,
      "latest_item_time": "2026-04-30T13:11:45+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-cohere-cohere",
      "source_name": "cohere(@cohere)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/49666ce6fe3e4cb786c6574684542ec5",
      "item_count": 9,
      "latest_item_time": "2026-04-07T18:14:19+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-dario-amodei-darioamodei",
      "source_name": "Dario Amodei(@DarioAmodei)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/42e6b4901b97498eab2ab64c07d56177",
      "item_count": 9,
      "latest_item_time": "2026-05-01T00:09:55+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-deeplearning-ai-deeplearningai",
      "source_name": "DeepLearning.AI(@DeepLearningAI)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/68b610deb24b47ae9a236811563cda86",
      "item_count": 9,
      "latest_item_time": "2026-04-29T02:20:52+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-deepseek-deepseek-ai",
      "source_name": "DeepSeek(@deepseek_ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/4a884d5e2f3740c5a26c9c093de6388a",
      "item_count": 9,
      "latest_item_time": "2026-05-02T11:34:21+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-demis-hassabis-demishassabis",
      "source_name": "Demis Hassabis(@demishassabis)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/6384ee3c656c48fea5e8b3cdacece4d0",
      "item_count": 9,
      "latest_item_time": "2026-03-26T17:03:19+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-dia-diabrowser",
      "source_name": "Dia(@diabrowser)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/65f321be670b4ffba7f40d0afd38c94d",
      "item_count": 9,
      "latest_item_time": "2026-05-07T18:18:58+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-eric-zakariasson-ericzakariasson",
      "source_name": "eric zakariasson(@ericzakariasson)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/a4bfe44bfc0d4c949da21ebd3f5f42a5",
      "item_count": 9,
      "latest_item_time": "2026-04-07T16:48:36+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-fei-fei-li-drfeifei",
      "source_name": "Fei-Fei Li(@drfeifei)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/326763c2f6154826babcfd71c5ab0f70",
      "item_count": 9,
      "latest_item_time": "2026-05-08T19:47:00+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-fellou-fellouai",
      "source_name": "Fellou(@FellouAI)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/c04abb206bbf4f91b22795024d6c0614",
      "item_count": 9,
      "latest_item_time": "2026-05-06T16:11:06+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-firecrawl-firecrawl-dev",
      "source_name": "Firecrawl(@firecrawl_dev)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/9f35c76341554bd78c2b9e63dc4fa5d8",
      "item_count": 9,
      "latest_item_time": "2026-05-06T23:42:49+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-fireworks-ai-fireworksai-hq",
      "source_name": "Fireworks AI(@FireworksAI_HQ)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/4900b3dcd592424687582ff9e0f148ea",
      "item_count": 9,
      "latest_item_time": "2026-04-29T10:59:12+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-fish-audio-fishaudio",
      "source_name": "Fish Audio(@FishAudio)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/be74da51698d4cefb12b39830d6cd201",
      "item_count": 9,
      "latest_item_time": "2026-03-16T20:10:48+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-flowiseai-flowiseai",
      "source_name": "FlowiseAI(@FlowiseAI)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/35a38c5646d946fb894d8c30c1d9629e",
      "item_count": 9,
      "latest_item_time": "2026-05-14T06:35:28+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-gary-marcus-garymarcus",
      "source_name": "Gary Marcus(@GaryMarcus)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/71ffd342cb5d478185ef7d55bdfca011",
      "item_count": 9,
      "latest_item_time": "2026-05-05T02:48:37+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-genspark-genspark-ai",
      "source_name": "Genspark(@genspark_ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/69d925d4a8d44221b03eecbe07bd0f74",
      "item_count": 9,
      "latest_item_time": "2026-05-04T23:11:31+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-google-ai-developers-googleaidevs",
      "source_name": "Google AI Developers(@googleaidevs)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/4de0bd2d5cef4333a0260dc8157054a7",
      "item_count": 9,
      "latest_item_time": "2026-05-01T16:10:11+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-google-ai-googleai",
      "source_name": "Google AI(@GoogleAI)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/6fb337feeec44ca38b79491b971d868d",
      "item_count": 9,
      "latest_item_time": "2026-05-04T18:39:22+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-google-gemini-app-geminiapp",
      "source_name": "Google Gemini App(@GeminiApp)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/af19d054e26a49129f23abfa82d9e268",
      "item_count": 9,
      "latest_item_time": "2026-05-11T21:00:48+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-greg-brockman-gdb",
      "source_name": "Greg Brockman(@gdb)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/831fac36aa0a49a9af79f35dc1c9b5d9",
      "item_count": 9,
      "latest_item_time": "2026-05-15T02:21:02+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-guizang-ai-op7418",
      "source_name": "歸藏(guizang.ai)(@op7418)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/e65b5e59fcb544918c1ba17f5758f0f8",
      "item_count": 9,
      "latest_item_time": "2026-05-06T04:10:52+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-hailuo-ai-minimax-hailuo-ai",
      "source_name": "Hailuo AI (MiniMax)(@Hailuo_AI)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/f299207df53745bca04a03db8d11c5aa",
      "item_count": 9,
      "latest_item_time": "2026-05-06T16:31:58+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-harrison-chase-hwchase17",
      "source_name": "Harrison Chase(@hwchase17)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/a9aff6b016c143ed8728dd86eb70d7db",
      "item_count": 9,
      "latest_item_time": "2026-05-11T16:14:16+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-heygen-heygen-official",
      "source_name": "HeyGen(@HeyGen_Official)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/6e8e7b42cb434818810f87bcf77d86fb",
      "item_count": 9,
      "latest_item_time": "2026-04-29T13:55:43+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-hunyuan-txhunyuan",
      "source_name": "Hunyuan(@TXhunyuan)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/a719880fe66e4156a111187f50dae91b",
      "item_count": 9,
      "latest_item_time": "2026-04-22T16:46:12+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-ideogram-ideogram-ai",
      "source_name": "Ideogram(@ideogram_ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/dceb5cd131b34c72a8376cba8ea5d864",
      "item_count": 9,
      "latest_item_time": "2026-04-14T19:43:38+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-jan-leike-janleike",
      "source_name": "Jan Leike(@janleike)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/b1013166769c49f8aa3fbdc222867054",
      "item_count": 9,
      "latest_item_time": "2026-04-28T20:16:21+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-jeff-dean-jeffdean",
      "source_name": "Jeff Dean(@JeffDean)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/b3d904c0d7c446558ef3a1e7f2eb362b",
      "item_count": 9,
      "latest_item_time": "2026-05-06T17:44:01+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-jerry-liu-jerryjliu0",
      "source_name": "Jerry Liu(@jerryjliu0)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/c6cfe7c0d6b74849997073233fdea840",
      "item_count": 9,
      "latest_item_time": "2026-04-01T15:15:09+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-jim-fan-drjimfan",
      "source_name": "Jim Fan(@DrJimFan)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/f510f6e7eecf456ca7e2895a46752888",
      "item_count": 9,
      "latest_item_time": "2026-03-13T12:29:21+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-jina-ai-jinaai",
      "source_name": "Jina AI(@JinaAI_)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/44d9fa384087448a94d3c8595f8d535e",
      "item_count": 9,
      "latest_item_time": "2026-05-01T17:08:33+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-julien-chaumond-julien-c",
      "source_name": "Julien Chaumond(@julien_c)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/c61046471f174d86bc0eb76cb44a21c3",
      "item_count": 9,
      "latest_item_time": "2026-05-12T15:17:41+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-justine-moore-venturetwins",
      "source_name": "Justine Moore(@venturetwins)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/564237c3de274d58a04f064920817888",
      "item_count": 9,
      "latest_item_time": "2026-05-11T09:31:09+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-kling-ai-kling-ai",
      "source_name": "Kling AI(@Kling_ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/862fee50a745423c87e2633b274caf1d",
      "item_count": 9,
      "latest_item_time": "2026-05-14T19:33:28+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-langchain-langchainai",
      "source_name": "LangChain(@LangChainAI)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/a7be8b61a1264ea7984abfaea3eff686",
      "item_count": 9,
      "latest_item_time": "2026-05-06T16:25:16+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-latent-space-latentspacepod",
      "source_name": "Latent.Space(@latentspacepod)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/dc2426bc8348495189b45451d1707a1c",
      "item_count": 9,
      "latest_item_time": "2026-05-02T23:47:09+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-lee-robinson-leerob",
      "source_name": "Lee Robinson(@leerob)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/77d5ce4736854b0ebae603e4b54d3095",
      "item_count": 9,
      "latest_item_time": "2026-05-12T15:41:09+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-lenny-rachitsky-lennysan",
      "source_name": "Lenny Rachitsky(@lennysan)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/adf65931519340f795e2336910b4cd15",
      "item_count": 9,
      "latest_item_time": "2026-04-09T17:56:46+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-lex-fridman-lexfridman",
      "source_name": "Lex Fridman(@lexfridman)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/ca2fa444b6ea4b8b974fe148056e497a",
      "item_count": 9,
      "latest_item_time": "2026-05-06T04:41:58+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-lijigang-com",
      "source_name": "李继刚(@lijigang_com)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/a8f7e2238039461cbc8bf55f5f194498",
      "item_count": 9,
      "latest_item_time": "2026-03-10T17:08:44+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-lilian-weng-lilianweng",
      "source_name": "Lilian Weng(@lilianweng)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/f01b088d5a39473e854b07143df77ec5",
      "item_count": 9,
      "latest_item_time": "2026-05-08T16:01:31+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-lmarena-ai-lmarena-ai",
      "source_name": "lmarena.ai(@lmarena_ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/4f63d960de644aeebd0aa97e4994dafe",
      "item_count": 9,
      "latest_item_time": "2026-05-04T22:53:00+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-logan-kilpatrick-officiallogank",
      "source_name": "Logan Kilpatrick(@OfficialLoganK)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/639cd13d44284e10ac89fbd1c5399767",
      "item_count": 9,
      "latest_item_time": "2026-05-07T16:03:04+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-lovable-lovable-dev",
      "source_name": "Lovable(@lovable_dev)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/320181c4651a41a08015946b55f704ab",
      "item_count": 9,
      "latest_item_time": "2026-05-06T15:01:44+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-manusai-manusai-hq",
      "source_name": "ManusAI(@ManusAI_HQ)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/94bb691baeff461686326af619beb116",
      "item_count": 9,
      "latest_item_time": "2026-05-01T23:08:57+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-mem0-mem0ai",
      "source_name": "mem0(@mem0ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/48aae530e0bf413aa7d44380f418e2e3",
      "item_count": 9,
      "latest_item_time": "2026-05-14T09:27:33+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-meng-shao-shao-meng",
      "source_name": "meng shao(@shao__meng)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/61f4b78554fb4b8fa5653ec5d924d15a",
      "item_count": 9,
      "latest_item_time": "2026-05-04T16:57:40+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-microsoft-research-msftresearch",
      "source_name": "Microsoft Research(@MSFTResearch)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/72dd496bfd9d44c5a5761a974630376d",
      "item_count": 9,
      "latest_item_time": "2026-04-30T22:04:00+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-midjourney-midjourney",
      "source_name": "Midjourney(@midjourney)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/424e67b19eed4500b7a440976bbd2ade",
      "item_count": 9,
      "latest_item_time": "2026-05-04T15:00:01+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-milvus-milvusio",
      "source_name": "Milvus(@milvusio)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/394acfaff8c44e09936f5bc0b8504f2c",
      "item_count": 9,
      "latest_item_time": "2026-04-28T17:12:10+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-mustafa-suleyman-mustafasuleyman",
      "source_name": "Mustafa Suleyman(@mustafasuleyman)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/b43bc203409e4c5a9c3ae86fe1ac00c9",
      "item_count": 9,
      "latest_item_time": "2026-05-05T03:38:58+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-naval-naval",
      "source_name": "Naval(@naval)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/6ebdf0d91eef4c149acd0ef110635866",
      "item_count": 9,
      "latest_item_time": "2026-04-24T19:15:41+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-nick-st-pierre-nickfloats",
      "source_name": "Nick St. Pierre(@nickfloats)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/f97a26863aec4425b021720d4f8e4ede",
      "item_count": 9,
      "latest_item_time": "2026-05-13T16:27:37+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-notion-notionhq",
      "source_name": "Notion(@NotionHQ)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/6326c63a2dfa445bbde88bea0c3112c2",
      "item_count": 9,
      "latest_item_time": "2026-05-04T23:36:39+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-ollama-ollama",
      "source_name": "ollama(@ollama)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/971dc1fc90da449bac23e5fad8a33d55",
      "item_count": 9,
      "latest_item_time": "2026-05-11T22:23:07+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-openai-developers-openaidevs",
      "source_name": "OpenAI Developers(@OpenAIDevs)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/e503a90c035c4b1d8f8dd34907d15bf4",
      "item_count": 9,
      "latest_item_time": "2026-05-10T18:53:21+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-openrouter-openrouterai",
      "source_name": "OpenRouter(@OpenRouterAI)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/c65c68f3713747bba863f92d6b5e996f",
      "item_count": 9,
      "latest_item_time": "2026-05-05T18:12:41+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-patrick-loeber-patloeber",
      "source_name": "Patrick Loeber(@patloeber)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/b9912ac9a29042cf8c834419dc44cb1f",
      "item_count": 9,
      "latest_item_time": "2026-05-05T20:47:13+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-paul-couvert-itspaulai",
      "source_name": "Paul Couvert(@itsPaulAi)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/900549ddadf04e839d3f7a17ebaba3fc",
      "item_count": 9,
      "latest_item_time": "2026-05-12T13:08:46+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-paul-graham-paulg",
      "source_name": "Paul Graham(@paulg)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/ce352bbf72e44033985bc756db2ee0e2",
      "item_count": 9,
      "latest_item_time": "2026-05-06T16:20:22+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-philipp-schmid-philschmid",
      "source_name": "Philipp Schmid(@_philschmid)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/3306d8b253ec4e03aca3c2e9967e7119",
      "item_count": 9,
      "latest_item_time": "2026-05-02T01:52:21+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-pika-pika-labs",
      "source_name": "Pika(@pika_labs)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/a55f6e33dd224235aabaabaaf9d58a06",
      "item_count": 9,
      "latest_item_time": "2026-05-04T15:00:02+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-qdrant-qdrant-engine",
      "source_name": "Qdrant(@qdrant_engine)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/80032d016d654eb4afe741ff34b7643d",
      "item_count": 9,
      "latest_item_time": "2026-05-01T15:14:01+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-qwen-alibaba-qwen",
      "source_name": "Qwen(@Alibaba_Qwen)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/acc648327c614d9b985b9fc3d737165b",
      "item_count": 9,
      "latest_item_time": "2026-05-11T09:54:46+00:00",
      "sampled_item_count": 3,
      "source_id": "socialmedia-recraft-recraftai",
      "source_name": "Recraft(@recraftai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/613f859e4bc440c5a28f40732840f5cf",
      "item_count": 9,
      "latest_item_time": "2026-05-11T17:34:29+00:00",
      "sampled_item_count": 7,
      "source_id": "socialmedia-replit-replit",
      "source_name": "Replit ⠕(@Replit)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/a636de3cbda0495daabd15b9fd298614",
      "item_count": 9,
      "latest_item_time": "2026-05-04T15:18:21+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-rowan-cheung-rowancheung",
      "source_name": "Rowan Cheung(@rowancheung)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/e6bb4f612dd24db5bc1a6811e6dd5820",
      "item_count": 9,
      "latest_item_time": "2026-05-05T14:22:35+00:00",
      "sampled_item_count": 3,
      "source_id": "socialmedia-runway-runwayml",
      "source_name": "Runway(@runwayml)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/baad3713defe4182844d2756b4c2c9ed",
      "item_count": 9,
      "latest_item_time": "2026-05-04T16:41:48+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-sahil-lavingia-shl",
      "source_name": "Sahil Lavingia(@shl)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/e30d4cd223f44bed9d404807105c8927",
      "item_count": 9,
      "latest_item_time": "2026-05-09T19:16:31+00:00",
      "sampled_item_count": 5,
      "source_id": "socialmedia-sam-altman-sama",
      "source_name": "Sam Altman(@sama)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/baa68dbd9a9e461a96fd9b2e3f35dcbf",
      "item_count": 9,
      "latest_item_time": "2026-05-02T12:11:51+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-satya-nadella-satyanadella",
      "source_name": "Satya Nadella(@satyanadella)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/30ad80be93c84e44acc37d5ddf31db57",
      "item_count": 9,
      "latest_item_time": "2026-05-07T17:13:19+00:00",
      "sampled_item_count": 5,
      "source_id": "socialmedia-simon-willison-simonw",
      "source_name": "Simon Willison(@simonw)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/6d7d398dd80b48d79669c92745d32cf6",
      "item_count": 9,
      "latest_item_time": "2026-05-06T12:03:54+00:00",
      "sampled_item_count": 1,
      "source_id": "socialmedia-skywork-skywork-ai",
      "source_name": "Skywork(@Skywork_ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/fafa6df3c67644b1a367a177240e0173",
      "item_count": 9,
      "latest_item_time": "2026-04-21T22:41:39+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-sualeh-asif-sualehasif996",
      "source_name": "Sualeh Asif(@sualehasif996)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/c961547e08df4396b3ab69367a07a1cd",
      "item_count": 9,
      "latest_item_time": "2026-05-11T16:44:53+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-suhail-suhail",
      "source_name": "Suhail(@Suhail)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/8324d65a63dc42c584a8c08cc8323c9f",
      "item_count": 9,
      "latest_item_time": "2026-04-29T20:49:27+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-sundar-pichai-sundarpichai",
      "source_name": "Sundar Pichai(@sundarpichai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/83b1ea38940b4a1d81ea57d1ffb12ad7",
      "item_count": 9,
      "latest_item_time": "2026-05-13T15:45:57+00:00",
      "sampled_item_count": 7,
      "source_id": "socialmedia-the-rundown-ai-therundownai",
      "source_name": "The Rundown AI(@TheRundownAI)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/4918efb13c47459b8dcaa79cfdf72d09",
      "item_count": 9,
      "latest_item_time": "2026-04-29T19:01:30+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-thomas-wolf-thom-wolf",
      "source_name": "Thomas Wolf(@Thom_Wolf)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/dbf37973e6fc4eae91d4be9669a78fc7",
      "item_count": 9,
      "latest_item_time": "2026-04-30T00:36:35+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-v0-v0",
      "source_name": "v0(@v0)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/7794c4268a504019a94af1778857a703",
      "item_count": 9,
      "latest_item_time": "2026-02-24T01:40:04+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-varun-mohan-mohansolo",
      "source_name": "Varun Mohan(@_mohansolo)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/9de19c78f7454ad08c956c1a00d237fe",
      "item_count": 9,
      "latest_item_time": "2026-05-15T08:40:27+00:00",
      "sampled_item_count": 2,
      "source_id": "socialmedia-vista8",
      "source_name": "向阳乔木(@vista8)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/2f1035ec6b28475987af06b600e1d04c",
      "item_count": 9,
      "latest_item_time": "2026-04-30T16:02:39+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-weaviate-vector-database-weaviate-io",
      "source_name": "Weaviate • vector database(@weaviate_io)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/4a8273800ed34a069eecdb6c5c1b9ccf",
      "item_count": 9,
      "latest_item_time": "2026-04-30T17:14:35+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-windsurf-windsurf-ai",
      "source_name": "Windsurf(@windsurf_ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/b1ab109f6afd42ab8ea32e17a19a3a3e",
      "item_count": 9,
      "latest_item_time": "2026-05-14T15:50:00+00:00",
      "sampled_item_count": 9,
      "source_id": "socialmedia-y-combinator-ycombinator",
      "source_name": "Y Combinator(@ycombinator)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/f5f4f928dede472ea55053672ad27ab6",
      "item_count": 9,
      "latest_item_time": "2026-05-04T16:44:38+00:00",
      "sampled_item_count": 1,
      "source_id": "socialmedia-yann-lecun-ylecun",
      "source_name": "Yann LeCun(@ylecun)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/ef7c70f9568d45f4915169fef4ce90b4",
      "item_count": 8,
      "latest_item_time": "2026-04-24T12:03:30+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-ai-at-meta-aiatmeta",
      "source_name": "AI at Meta(@AIatMeta)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/a02496979a0e4d86baf2b72c24db52a4",
      "item_count": 8,
      "latest_item_time": "2026-03-24T23:59:57+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-aman-sanger-amanrsanger",
      "source_name": "Aman Sanger(@amanrsanger)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/5fb1814c610c4af2911caa98c5c5ef82",
      "item_count": 8,
      "latest_item_time": "2026-05-05T21:08:54+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-amjad-masad-amasad",
      "source_name": "Amjad Masad(@amasad)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/a3eb6beb2d894da3a9b7ab6d2e46790e",
      "item_count": 8,
      "latest_item_time": "2026-05-07T18:02:57+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-andrew-chen-andrewchen",
      "source_name": "andrew chen(@andrewchen)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/f54b2b40185943ce8f48a880110b7bc2",
      "item_count": 8,
      "latest_item_time": "2026-04-22T02:10:13+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-binyuan-hui-huybery",
      "source_name": "Binyuan Hui(@huybery)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/5287b4e0e13a4ab7ab7b1d56f9d88960",
      "item_count": 8,
      "latest_item_time": "2026-05-06T16:15:44+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-cursor-cursor-ai",
      "source_name": "Cursor(@cursor_ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/ddfdcdd4e390495c942f0b5da62af0fb",
      "item_count": 8,
      "latest_item_time": "2026-05-05T02:41:21+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-eric-jing-ericjing-ai",
      "source_name": "Eric Jing(@ericjing_ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/f8a106a09a7d404fb8de7eb0c5ddd2a2",
      "item_count": 8,
      "latest_item_time": "2026-05-04T16:33:18+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-figma-figma",
      "source_name": "Figma(@figma)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/a99538443a484fcc846bdcc8f50745ec",
      "item_count": 8,
      "latest_item_time": "2026-05-01T16:01:19+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-google-deepmind-googledeepmind",
      "source_name": "Google DeepMind(@GoogleDeepMind)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/fc16750ce50741f1b1f05ea1fb29436f",
      "item_count": 8,
      "latest_item_time": "2026-04-24T07:06:35+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-hugging-face-huggingface",
      "source_name": "Hugging Face(@huggingface)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/57831559d22440debbfb2f2528e4ba84",
      "item_count": 8,
      "latest_item_time": "2026-04-09T18:58:45+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-ian-goodfellow-goodfellow-ian",
      "source_name": "Ian Goodfellow(@goodfellow_ian)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/78d7b99318b04b309b04000f7e24da29",
      "item_count": 8,
      "latest_item_time": "2026-04-16T15:36:13+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-mike-krieger-mikeyk",
      "source_name": "Mike Krieger(@mikeyk)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/8d2d03aea8af49818096da4ea00409d1",
      "item_count": 8,
      "latest_item_time": "2026-04-30T23:06:24+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-mistral-ai-mistralai",
      "source_name": "Mistral AI(@MistralAI)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/5d749cc613ec4069bb2a47334739e1b6",
      "item_count": 8,
      "latest_item_time": "2026-04-23T07:39:32+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-monica-im-hey-im-monica",
      "source_name": "Monica_IM(@hey_im_monica)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/4d2d4165a7524217a08d3f57f27fa190",
      "item_count": 8,
      "latest_item_time": "2026-05-04T04:34:32+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-richard-socher-richardsocher",
      "source_name": "Richard Socher(@RichardSocher)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/5fca8ccd87344d388bc863304ed6fd86",
      "item_count": 8,
      "latest_item_time": "2026-05-04T17:57:54+00:00",
      "sampled_item_count": 1,
      "source_id": "socialmedia-scott-wu-scottwu46",
      "source_name": "Scott Wu(@ScottWu46)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/2de92402f4a24c90bb27e7580b93a878",
      "item_count": 8,
      "latest_item_time": "2026-04-24T21:21:51+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-taranjeet-taranjeetio",
      "source_name": "Taranjeet(@taranjeetio)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/fdd601ea751949e7bec9e4cdad7c8e6c",
      "item_count": 7,
      "latest_item_time": "2026-05-06T14:09:37+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-perplexity-perplexity-ai",
      "source_name": "Perplexity(@perplexity_ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/d5fc365556e641cba2278f501e8c6f92",
      "item_count": 7,
      "latest_item_time": "2026-04-23T07:26:58+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-stanford-ai-lab-stanfordailab",
      "source_name": "Stanford AI Lab(@StanfordAILab)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/d8121d969fb34c7daad2dd2aac4ba270",
      "item_count": 5,
      "latest_item_time": "2026-03-16T23:24:00+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-arthur-mensch-arthurmensch",
      "source_name": "Arthur Mensch(@arthurmensch)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/6bbf31cac345443585c3280320ba9009",
      "item_count": 5,
      "latest_item_time": "2026-04-29T15:45:00+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-berkeley-ai-research-berkeley-ai",
      "source_name": "Berkeley AI Research(@berkeley_ai)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/97f1484ae48c430fbbf3438099743674",
      "item_count": 5,
      "latest_item_time": "2026-05-04T02:33:59+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-dotey",
      "source_name": "宝玉(@dotey)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/5dbd038a8f5140938d0877511571797b",
      "item_count": 4,
      "latest_item_time": "2026-05-08T14:47:57+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-clem-129303-clementdelangue",
      "source_name": "clem 🤗(@ClementDelangue)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/3ca3c7698fd04611a0e7d14fae93c84c",
      "item_count": 4,
      "latest_item_time": "2026-04-07T17:48:19+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-kevin-weil-127482-127480-kevinweil",
      "source_name": "Kevin Weil 🇺🇸(@kevinweil)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/67e259bd5be544ce84bbc867eace54c2",
      "item_count": 4,
      "latest_item_time": "2026-04-21T13:47:55+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-llamaindex-129433-llama-index",
      "source_name": "LlamaIndex 🦙(@llama_index)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/63316630d94543f5a6480f230f483008",
      "item_count": 4,
      "latest_item_time": "2026-05-16T20:13:06+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-marc-andreessen-127482-127480-pmarca",
      "source_name": "Marc Andreessen 🇺🇸(@pmarca)"
    },
    {
      "feed_url": "https://api.xgo.ing/rss/user/244eb9fa77ce4fa3b7fa5ceba80027a4",
      "item_count": 2,
      "latest_item_time": "2025-05-23T14:50:37+00:00",
      "sampled_item_count": 0,
      "source_id": "socialmedia-barsee-128054-heybarsee",
      "source_name": "Barsee 🐶(@heyBarsee)"
    }
  ]
}
```

## 3. Input Sample Summary

```json
{
  "items_sampled": 50,
  "items_too_short": 0,
  "items_with_raw_content": 50,
  "items_with_summary_only": 0,
  "languages": {
    "en_or_unknown": 48,
    "zh": 2
  },
  "source_count": 13,
  "time_range": {
    "max_created_at": "2026-05-17T03:44:09.320200+00:00",
    "min_created_at": "2026-05-17T03:44:09.288276+00:00"
  },
  "top_sources": [
    [
      "socialmedia-y-combinator-ycombinator",
      9
    ],
    [
      "socialmedia-the-rundown-ai-therundownai",
      7
    ],
    [
      "socialmedia-replit-replit",
      7
    ],
    [
      "socialmedia-sam-altman-sama",
      5
    ],
    [
      "socialmedia-simon-willison-simonw",
      5
    ],
    [
      "socialmedia-ray-dalio-raydalio",
      4
    ],
    [
      "socialmedia-recraft-recraftai",
      3
    ],
    [
      "socialmedia-runway-runwayml",
      3
    ],
    [
      "socialmedia-xai-xai",
      2
    ],
    [
      "socialmedia-vista8",
      2
    ]
  ]
}
```

## 4. Item Card Quality

```json
{
  "avg_confidence": 0.659,
  "avg_confidence_by_tier": {
    "full": 0.825,
    "minimal": 0.55,
    "standard": 0.685
  },
  "avg_tokens_by_tier": {
    "mixed_llm": 4789.0
  },
  "card_tier_distribution": {
    "full": 8,
    "minimal": 18,
    "standard": 24
  },
  "content_role_distribution": {
    "aggregator": 2,
    "analysis": 4,
    "commentary": 5,
    "low_signal": 2,
    "report": 24,
    "source_material": 13
  },
  "entity_count_distribution": {
    "1": 8,
    "2": 3,
    "3": 11,
    "4": 13,
    "5": 8,
    "6": 4,
    "7": 2,
    "8": 1
  },
  "heuristic_card_fallback_count": 5,
  "item_cards_failed": 1,
  "item_cards_generated": 50,
  "item_cards_generated_or_reused": 50,
  "item_cards_reused": 0,
  "llm_failures_by_tier": {
    "unknown": 1
  },
  "samples": [
    {
      "item_id": "item_00be6a3d0d23417aa50bb96fe5709725",
      "role": "report",
      "summary": "ok other than more goblins, i think this reasonably well matches what we are prioritizing! 💬 276 🔄 64 ❤️ 1611 👀 254897 📊 335 ⚡ Powered by xgo.ing",
      "title": "ok other than more goblins, i think this reasonably well matches what we are prioritizing!"
    },
    {
      "item_id": "item_01d3b459362744f2860ac73782289721",
      "role": "report",
      "summary": "Holding people accountable means understanding them and their circumstances well enough to assess whether they can and should do some things differently, getting in sync with them about that, and, if they can't adequately do what is required, removing them from their jobs. It is not micromanaging them, nor is it expecting them to be perfect (holding particu…",
      "title": "Holding people accountable means understanding them and their circumstances well enough to assess wh..."
    },
    {
      "item_id": "item_09ee50b604134e9d8c9d9b1118dfb309",
      "role": "report",
      "summary": "Today's the deadline to apply for YC Summer 2026. ycombinator.com/apply 💬 40 🔄 21 ❤️ 279 👀 109645 📊 64 ⚡ Powered by xgo.ing",
      "title": "Today's the deadline to apply for YC Summer 2026. https://t.co/gNl84El3BS"
    },
    {
      "item_id": "item_0df6b85a16f442e89122528fdde71cd1",
      "role": "report",
      "summary": "Top stories in robotics today: - Meta snaps up robotics startup ARI - 1X opens massive NEO humanoid factory - Figure claims it can build a robot every hour - Uber to turn its drivers into an AV sensor grid - Quick hits on other robotics news 💬 4 🔄 1 ❤️ 14 👀 2575 📊 5 ⚡ Powered by xgo.ing",
      "title": "Top stories in robotics today: - Meta snaps up robotics startup ARI - 1X opens massive NEO humanoid..."
    },
    {
      "item_id": "item_18889d042ab147f8b74ba8c1e4b93858",
      "role": "report",
      "summary": "Under-reported details of xAI/Anthropic Colossus data center deal: Anthropic gets Colossus 1, xAI keeps Colossus 2; Colossus 1 has bad environmental record; xAI shut down older models on short notice.",
      "title": "Under-reported details of the xAI/Anthropic Colossus data center deal"
    },
    {
      "item_id": "item_18d19b3a28a84993b1f6bf6c9e975e79",
      "role": "low_signal",
      "summary": "Replit celebrates Mother's Day by highlighting mothers who build apps.",
      "title": "Sarra builds apps with her two sons. Noni shipped Bamboo Brain..."
    },
    {
      "item_id": "item_1b71b0dbfc2e4244b9dd367eb0c48368",
      "role": "source_material",
      "summary": "xAI announces Grok 4.3 on the API, claiming it tops leaderboards in agentic tool calling and instruction following, ranks #1 in enterprise domains, supports 1M token context, and is priced at $1.25/m input and $2.50/m output.",
      "title": "Grok 4.3 is now live on the xAI API"
    },
    {
      "item_id": "item_20c07880c37340d79b74c4e35d16ec38",
      "role": "source_material",
      "summary": "Recraft announces that its V4 image generation models are now available on OpenRouter, tuned for high aesthetics.",
      "title": "Recraft V4 and V4 Pro available on OpenRouter"
    },
    {
      "item_id": "item_21c5a4e1514648b59554a685b4b83499",
      "role": "analysis",
      "summary": "I don't think they'll be taking Q&A so I'll ask here: @jarredsumner do you end up actually reading all of that chatter between the review bots on a PR? 💬 5 🔄 2 ❤️ 52 👀 23739 📊 10 ⚡ Powered by xgo.ing",
      "title": "I don't think they'll be taking Q&A so I'll ask here: @jarredsumner do you end up actually readi..."
    },
    {
      "item_id": "item_25f9d229c978477d9d6557774c3c6905",
      "role": "report",
      "summary": "I had Claude Code for web build me this WebAssembly playground for trying out the new Redis array commands tools.simonwillison.net/redis-array More notes here: simonwillison.net/2026/May/4/red… 💬 1 🔄 0 ❤️ 25 👀 5722 📊 4 ⚡ Powered by xgo.ing",
      "title": "I had Claude Code for web build me this WebAssembly playground for trying out the new Redis array co..."
    }
  ],
  "warnings_distribution": {
    "aggregator": 1,
    "heuristic_card": 5,
    "low_signal": 1,
    "marketing_promotion": 1,
    "minimal_card": 18,
    "opinion_claim": 1,
    "partial_context": 1,
    "personal opinion": 1,
    "social_media_opinion": 2,
    "social_media_promotion": 1,
    "speculation": 1
  }
}
```

## 5. Item-Item Relation Quality

```json
{
  "avg_confidence": 0.874,
  "candidate_pairs_considered": 161,
  "different": 150,
  "duplicate": 0,
  "examples": [
    {
      "candidate_item_title": "I don't think they'll be taking Q&A so I'll ask here: @jarredsumner do you end up actually readi...",
      "confidence": 0.95,
      "new_item_title": "kicking off a bunch of codex tasks, running around with my kid in the sunshine, and then coming back...",
      "primary_relation": "different",
      "published_at": "2026-05-09T19:12:17+00:00",
      "reason": "Candidate is about reading review bots chatter, while new item is about Codex tasks and personal experience. No shared entities or events.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-sam-altman-sama"
    },
    {
      "candidate_item_title": "Recraft V4 helps you create expressive, story-driven scenes full of awkward timing, emotional chaos,...",
      "confidence": 0.95,
      "new_item_title": "kicking off a bunch of codex tasks, running around with my kid in the sunshine, and then coming back...",
      "primary_relation": "different",
      "published_at": "2026-05-09T19:12:17+00:00",
      "reason": "Candidate is about Recraft V4 illustration style, while new item is about Codex tasks. No shared entities or events.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-sam-altman-sama"
    },
    {
      "candidate_item_title": "what would you most like to see improve in our next model?",
      "confidence": 0.95,
      "new_item_title": "kicking off a bunch of codex tasks, running around with my kid in the sunshine, and then coming back...",
      "primary_relation": "different",
      "published_at": "2026-05-09T19:12:17+00:00",
      "reason": "Candidate is a question about model improvements, while new item is about Codex tasks. No shared entities or events.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-sam-altman-sama"
    },
    {
      "candidate_item_title": "ok other than more goblins, i think this reasonably well matches what we are prioritizing!",
      "confidence": 0.95,
      "new_item_title": "kicking off a bunch of codex tasks, running around with my kid in the sunshine, and then coming back...",
      "primary_relation": "different",
      "published_at": "2026-05-09T19:12:17+00:00",
      "reason": "Candidate is about prioritizing features, while new item is about Codex tasks. No shared entities or events.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-sam-altman-sama"
    },
    {
      "candidate_item_title": "Today's the deadline to apply for YC Summer 2026. https://t.co/gNl84El3BS",
      "confidence": 0.95,
      "new_item_title": "kicking off a bunch of codex tasks, running around with my kid in the sunshine, and then coming back...",
      "primary_relation": "different",
      "published_at": "2026-05-09T19:12:17+00:00",
      "reason": "Candidate is about YC application deadline, while new item is about Codex tasks. No shared entities or events.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-sam-altman-sama"
    },
    {
      "candidate_item_title": "Read more: https://t.co/3YEhHmqg3g",
      "confidence": 0.95,
      "new_item_title": "From when the user stops speaking to when the Character starts replying is just 1.75 seconds. Under ...",
      "primary_relation": "different",
      "published_at": "2026-05-04T17:30:29+00:00",
      "reason": "The new item discusses voice/video model latency; the candidate is a generic promotional link with no relevant content.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-runway-runwayml"
    },
    {
      "candidate_item_title": "Today's the deadline to apply for YC Summer 2026. https://t.co/gNl84El3BS",
      "confidence": 0.95,
      "new_item_title": "From when the user stops speaking to when the Character starts replying is just 1.75 seconds. Under ...",
      "primary_relation": "different",
      "published_at": "2026-05-04T17:30:29+00:00",
      "reason": "The new item is about AI latency; the candidate is about YC application deadline.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-runway-runwayml"
    },
    {
      "candidate_item_title": "ok other than more goblins, i think this reasonably well matches what we are prioritizing!",
      "confidence": 0.95,
      "new_item_title": "From when the user stops speaking to when the Character starts replying is just 1.75 seconds. Under ...",
      "primary_relation": "different",
      "published_at": "2026-05-04T17:30:29+00:00",
      "reason": "The new item is about AI latency; the candidate is a casual comment about goblins and priorities.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-runway-runwayml"
    },
    {
      "candidate_item_title": "pretty excited for voice models to get great its interesting to watch how people are already starti...",
      "confidence": 0.85,
      "new_item_title": "From when the user stops speaking to when the Character starts replying is just 1.75 seconds. Under ...",
      "primary_relation": "different",
      "published_at": "2026-05-04T17:30:29+00:00",
      "reason": "Both mention voice models but the new item is a specific latency report, while the candidate is a general excitement about voice models.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-runway-runwayml"
    },
    {
      "candidate_item_title": "I don't think they'll be taking Q&A so I'll ask here: @jarredsumner do you end up actually readi...",
      "confidence": 0.95,
      "new_item_title": "From when the user stops speaking to when the Character starts replying is just 1.75 seconds. Under ...",
      "primary_relation": "different",
      "published_at": "2026-05-04T17:30:29+00:00",
      "reason": "The new item is about AI latency; the candidate is a question about reading PR chatter.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-runway-runwayml"
    }
  ],
  "fold_candidates": 0,
  "llm_item_relation_calls": 33,
  "low_confidence_examples": [
    {
      "candidate_item_title": "what would you most like to see improve in our next model?",
      "confidence": 0.2,
      "new_item_title": "ok other than more goblins, i think this reasonably well matches what we are prioritizing!",
      "primary_relation": "different",
      "published_at": "2026-05-09T16:47:43+00:00",
      "reason": "The new item is a comment about priorities, while the candidate is a question about model improvements; no shared event or topic.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-sam-altman-sama"
    },
    {
      "candidate_item_title": "I don't think they'll be taking Q&A so I'll ask here: @jarredsumner do you end up actually readi...",
      "confidence": 0.2,
      "new_item_title": "ok other than more goblins, i think this reasonably well matches what we are prioritizing!",
      "primary_relation": "different",
      "published_at": "2026-05-09T16:47:43+00:00",
      "reason": "The new item is about priorities, while the candidate is a question about reading review bot chatter; no shared event or topic.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-sam-altman-sama"
    },
    {
      "candidate_item_title": "From when the user stops speaking to when the Character starts replying is just 1.75 seconds. Under ...",
      "confidence": 0.2,
      "new_item_title": "ok other than more goblins, i think this reasonably well matches what we are prioritizing!",
      "primary_relation": "different",
      "published_at": "2026-05-09T16:47:43+00:00",
      "reason": "The new item is about priorities, while the candidate is about response time of a character; no shared event or topic.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-sam-altman-sama"
    },
    {
      "candidate_item_title": "kicking off a bunch of codex tasks, running around with my kid in the sunshine, and then coming back...",
      "confidence": 0.2,
      "new_item_title": "ok other than more goblins, i think this reasonably well matches what we are prioritizing!",
      "primary_relation": "different",
      "published_at": "2026-05-09T16:47:43+00:00",
      "reason": "The new item is about priorities, while the candidate is about coding tasks; no shared event or topic.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-sam-altman-sama"
    },
    {
      "candidate_item_title": "Read more: https://t.co/yZgH0hEATU",
      "confidence": 0.2,
      "new_item_title": "ok other than more goblins, i think this reasonably well matches what we are prioritizing!",
      "primary_relation": "different",
      "published_at": "2026-05-09T16:47:43+00:00",
      "reason": "The new item is about priorities, while the candidate is a link to an article; no shared event or topic.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-sam-altman-sama"
    },
    {
      "candidate_item_title": "AI data centers are heading out to sea. Panthalassa just raised $140 M led by Peter Thiel for wave-...",
      "confidence": 0.55,
      "new_item_title": "Join the Runway team in Denver on June 4th at our annual CVPR Friends Dinner for conversation, cockt...",
      "primary_relation": "different",
      "published_at": "2026-05-05T14:22:34+00:00",
      "reason": "No clear relation; unrelated topics: AI data centers vs. Runway dinner event.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-runway-runwayml"
    },
    {
      "candidate_item_title": "Katie has always had a unique way of seeing around corners - would highly recommend working with her...",
      "confidence": 0.55,
      "new_item_title": "Join the Runway team in Denver on June 4th at our annual CVPR Friends Dinner for conversation, cockt...",
      "primary_relation": "different",
      "published_at": "2026-05-05T14:22:34+00:00",
      "reason": "No clear relation; candidate is about a personal recommendation, unrelated to Runway event.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-runway-runwayml"
    },
    {
      "candidate_item_title": "we love you too!",
      "confidence": 0.55,
      "new_item_title": "Join the Runway team in Denver on June 4th at our annual CVPR Friends Dinner for conversation, cockt...",
      "primary_relation": "different",
      "published_at": "2026-05-05T14:22:34+00:00",
      "reason": "No clear relation; candidate is about OpenAI rate limits, unrelated to Runway event.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-runway-runwayml"
    },
    {
      "candidate_item_title": "Today's the deadline to apply for YC Summer 2026. https://t.co/gNl84El3BS",
      "confidence": 0.55,
      "new_item_title": "Join the Runway team in Denver on June 4th at our annual CVPR Friends Dinner for conversation, cockt...",
      "primary_relation": "different",
      "published_at": "2026-05-05T14:22:34+00:00",
      "reason": "No clear relation; candidate is about YC application deadline, unrelated to Runway event.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-runway-runwayml"
    },
    {
      "candidate_item_title": "ok other than more goblins, i think this reasonably well matches what we are prioritizing!",
      "confidence": 0.55,
      "new_item_title": "what would you most like to see improve in our next model?",
      "primary_relation": "different",
      "published_at": "2026-05-09T16:34:08+00:00",
      "reason": "The new item is a question about model improvement, unrelated to the candidate which is a comment about goblins and priorities.",
      "secondary_roles": [],
      "should_fold": false,
      "source": "socialmedia-sam-altman-sama"
    }
  ],
  "near_duplicate": 0,
  "related_with_new_info": 6,
  "related_with_new_info_count": 6,
  "relations_by_primary_relation": {
    "different": 150,
    "related_with_new_info": 6,
    "uncertain": 5
  },
  "uncertain_count": 5
}
```

## 6. Item-Cluster Relation Quality

```json
{
  "actions": {
    "attach_to_cluster": 10,
    "create_new_cluster": 1
  },
  "attached_existing_clusters": 2,
  "avg_confidence": 0.618,
  "avg_items_per_cluster": 1.222,
  "candidate_clusters_considered": 9,
  "cluster_samples": [
    {
      "cluster_status": "active",
      "cluster_title": "Recraft V4 helps you create expressive, story-driven scenes full of awkward timing, emotional chaos,...",
      "core_facts": [
        "Recraft V4 helps you create expressive, story-driven scenes full of awkward timing, emotional chaos, and painfully relatable moments — all in one consistent illustration style. Prompts ↓ 💬 3 🔄 3 ❤️ 47 👀 2720 📊 17 ⚡ Powered by xgo.ing"
      ],
      "item_count": 3,
      "known_angles": [],
      "representative_items": [
        "item_ecb2725d671749cab9933fb836cfd0d5"
      ]
    },
    {
      "cluster_status": "active",
      "cluster_title": "what would you most like to see improve in our next model?",
      "core_facts": [],
      "item_count": 1,
      "known_angles": [],
      "representative_items": [
        "item_c712ff5cef3e421db70f5146d235c11c"
      ]
    },
    {
      "cluster_status": "active",
      "cluster_title": "Grok 4.3 release",
      "core_facts": [
        "xAI announces Grok 4.3 on the API, claiming it tops leaderboards in agentic tool calling and instruction following, ranks #1 in enterprise domains, supports 1M token context, and is priced at $1.25/m input and $2.50/m output."
      ],
      "item_count": 1,
      "known_angles": [],
      "representative_items": [
        "item_1b71b0dbfc2e4244b9dd367eb0c48368"
      ]
    },
    {
      "cluster_status": "active",
      "cluster_title": "Give me someone who can be responsible for an entire area",
      "core_facts": [
        "Ray Dalio shares a principle about hiring senior managers who can handle an entire area, design, hire, and sort to achieve goals."
      ],
      "item_count": 1,
      "known_angles": [],
      "representative_items": [
        "item_e708151c4c9441769550c7cb193e1d53"
      ]
    },
    {
      "cluster_status": "active",
      "cluster_title": "AI-native discovery engine development",
      "core_facts": [
        "Frontier models have reached PhD-level scientific reasoning, enabling closed discovery loops."
      ],
      "item_count": 1,
      "known_angles": [],
      "representative_items": [
        "item_e4ac47141d1d4fa49f8e298fe2bf85a6"
      ]
    },
    {
      "cluster_status": "active",
      "cluster_title": "AI news digest",
      "core_facts": [
        "Digest of AI news: New Googlebooks, Gemini Intelligence for Android, Google circles SpaceX for orbital AI compute, Claude Code as Wall Street analyst, Amazon AI scoreboard, and more."
      ],
      "item_count": 1,
      "known_angles": [],
      "representative_items": [
        "item_bfb89d30b6a44b9c9978d61148575cb3"
      ]
    },
    {
      "cluster_status": "active",
      "cluster_title": "GPT-5.5 and GPT Image 2 available on Skywork",
      "core_facts": [
        "GPT-5.5 and GPT Image 2 are now available in Skywork, OpenAI's latest models."
      ],
      "item_count": 1,
      "known_angles": [],
      "representative_items": [
        "item_af5e63272e374d69a54a9d51f005599b"
      ]
    },
    {
      "cluster_status": "active",
      "cluster_title": "Possible Bun port from Zig to Rust",
      "core_facts": [
        "Simon Willison notes that Bun appears to be exploring a port from Zig to Rust based on a PORTING.md guide for coding agents."
      ],
      "item_count": 1,
      "known_angles": [],
      "representative_items": [
        "item_27881692a5774afdb2f65f66660d024f"
      ]
    },
    {
      "cluster_status": "active",
      "cluster_title": "Adialante launches mobile MRI for cancer screening",
      "core_facts": [
        "Adialante is making mobile MRI accessible, cutting costs to hundreds per scan and wait times to hours, aiming for annual cancer screening."
      ],
      "item_count": 1,
      "known_angles": [],
      "representative_items": [
        "item_8b5e5c4d6e4e48bb8fcf5beb69063bac"
      ]
    }
  ],
  "created_clusters": 9,
  "follow_up_event": {
    "false": 10,
    "true": 1
  },
  "manual_review_suggestions": {
    "high_uncertain": [],
    "possible_miscluster": [],
    "possible_missplit": [
      {
        "cluster_id": "cluster_f8be7c6e426b4709aee0e96aa88ef900",
        "confidence": 0.6,
        "created_at": "2026-05-17T03:49:20.492047+00:00",
        "decision_source": "llm",
        "evidence_json": "[\"The item uses 'our next model' indicating a future release from the same entity as Recraft V4.\", \"The entities are similar ('Powered') and the context is about model improvement.\"]",
        "follow_up_event": 1,
        "id": 3,
        "incremental_value": 1,
        "input_fingerprint": "6fd68440cb7dfe1d370f201c695b43db39de4a76f11fce23bd68ee2ca11763ba",
        "item_id": "item_c712ff5cef3e421db70f5146d235c11c",
        "llm_call_id": 72,
        "model": "deepseek-v4-flash",
        "new_angles_json": "[\"user feedback request for next model version\"]",
        "new_facts_json": "[]",
        "primary_relation": "follow_up",
        "prompt_version": "item_cluster_relation_v1",
        "reason": "The new item is a social media post asking for suggestions on what to improve in the next model, which is a follow-up to the Recraft V4 release cluster, as it seeks input for a future iteration.",
        "report_value": 1,
        "same_event": 0,
        "same_topic": 1,
        "schema_version": "semantic_v1",
        "secondary_roles_json": "[\"user_feedback\"]",
        "should_notify": 0,
        "should_update_cluster_card": 0,
        "updated_at": "2026-05-17T03:49:20.492047+00:00"
      }
    ],
    "top_review_items_or_clusters": [
      {
        "cluster_id": "cluster_f8be7c6e426b4709aee0e96aa88ef900",
        "confidence": 0.6,
        "created_at": "2026-05-17T03:49:20.492047+00:00",
        "decision_source": "llm",
        "evidence_json": "[\"The item uses 'our next model' indicating a future release from the same entity as Recraft V4.\", \"The entities are similar ('Powered') and the context is about model improvement.\"]",
        "follow_up_event": 1,
        "id": 3,
        "incremental_value": 1,
        "input_fingerprint": "6fd68440cb7dfe1d370f201c695b43db39de4a76f11fce23bd68ee2ca11763ba",
        "item_id": "item_c712ff5cef3e421db70f5146d235c11c",
        "llm_call_id": 72,
        "model": "deepseek-v4-flash",
        "new_angles_json": "[\"user feedback request for next model version\"]",
        "new_facts_json": "[]",
        "primary_relation": "follow_up",
        "prompt_version": "item_cluster_relation_v1",
        "reason": "The new item is a social media post asking for suggestions on what to improve in the next model, which is a follow-up to the Recraft V4 release cluster, as it seeks input for a future iteration.",
        "report_value": 1,
        "same_event": 0,
        "same_topic": 1,
        "schema_version": "semantic_v1",
        "secondary_roles_json": "[\"user_feedback\"]",
        "should_notify": 0,
        "should_update_cluster_card": 0,
        "updated_at": "2026-05-17T03:49:20.492047+00:00"
      }
    ]
  },
  "multi_item_cluster_count": 1,
  "relations": {
    "experience": 1,
    "follow_up": 1,
    "new_info": 6,
    "source_material": 3
  },
  "same_event": {
    "false": 2,
    "true": 9
  },
  "same_topic": {
    "true": 11
  },
  "should_notify_count": 0,
  "should_update_cluster_card_count": 9,
  "top_clusters": [
    {
      "cluster_id": "cluster_db316cfd77824330974b6c7ff7e16042",
      "cluster_title": "Recraft V4 helps you create expressive, story-driven scenes full of awkward timing, emotional chaos,...",
      "item_count": 3
    },
    {
      "cluster_id": "cluster_f8be7c6e426b4709aee0e96aa88ef900",
      "cluster_title": "what would you most like to see improve in our next model?",
      "item_count": 1
    },
    {
      "cluster_id": "cluster_764866b44bdf466a814c7c2b6bbe5bd0",
      "cluster_title": "Grok 4.3 release",
      "item_count": 1
    },
    {
      "cluster_id": "cluster_44db0f583dfa4d4b8e6beb322bcd3b78",
      "cluster_title": "Give me someone who can be responsible for an entire area",
      "item_count": 1
    },
    {
      "cluster_id": "cluster_63c8c2e6f1634774a1f4d9f9f475d967",
      "cluster_title": "AI-native discovery engine development",
      "item_count": 1
    },
    {
      "cluster_id": "cluster_5e93e9b8e1994fca9ff340ea9d66fc1e",
      "cluster_title": "AI news digest",
      "item_count": 1
    },
    {
      "cluster_id": "cluster_9e31a7f9923c41bfaa1f529bfb26b777",
      "cluster_title": "GPT-5.5 and GPT Image 2 available on Skywork",
      "item_count": 1
    },
    {
      "cluster_id": "cluster_71d3a6736473447b81c8b7a21ca535c1",
      "cluster_title": "Possible Bun port from Zig to Rust",
      "item_count": 1
    },
    {
      "cluster_id": "cluster_b523b7b61b1b4f1889eae0e2bad220b2",
      "cluster_title": "Adialante launches mobile MRI for cancer screening",
      "item_count": 1
    }
  ],
  "uncertain_clusters": 0
}
```

## 7. Cluster Quality Samples

```json
[
  {
    "cluster_status": "active",
    "cluster_title": "Recraft V4 helps you create expressive, story-driven scenes full of awkward timing, emotional chaos,...",
    "core_facts": [
      "Recraft V4 helps you create expressive, story-driven scenes full of awkward timing, emotional chaos, and painfully relatable moments — all in one consistent illustration style. Prompts ↓ 💬 3 🔄 3 ❤️ 47 👀 2720 📊 17 ⚡ Powered by xgo.ing"
    ],
    "item_count": 3,
    "known_angles": [],
    "representative_items": [
      "item_ecb2725d671749cab9933fb836cfd0d5"
    ]
  },
  {
    "cluster_status": "active",
    "cluster_title": "what would you most like to see improve in our next model?",
    "core_facts": [],
    "item_count": 1,
    "known_angles": [],
    "representative_items": [
      "item_c712ff5cef3e421db70f5146d235c11c"
    ]
  },
  {
    "cluster_status": "active",
    "cluster_title": "Grok 4.3 release",
    "core_facts": [
      "xAI announces Grok 4.3 on the API, claiming it tops leaderboards in agentic tool calling and instruction following, ranks #1 in enterprise domains, supports 1M token context, and is priced at $1.25/m input and $2.50/m output."
    ],
    "item_count": 1,
    "known_angles": [],
    "representative_items": [
      "item_1b71b0dbfc2e4244b9dd367eb0c48368"
    ]
  },
  {
    "cluster_status": "active",
    "cluster_title": "Give me someone who can be responsible for an entire area",
    "core_facts": [
      "Ray Dalio shares a principle about hiring senior managers who can handle an entire area, design, hire, and sort to achieve goals."
    ],
    "item_count": 1,
    "known_angles": [],
    "representative_items": [
      "item_e708151c4c9441769550c7cb193e1d53"
    ]
  },
  {
    "cluster_status": "active",
    "cluster_title": "AI-native discovery engine development",
    "core_facts": [
      "Frontier models have reached PhD-level scientific reasoning, enabling closed discovery loops."
    ],
    "item_count": 1,
    "known_angles": [],
    "representative_items": [
      "item_e4ac47141d1d4fa49f8e298fe2bf85a6"
    ]
  },
  {
    "cluster_status": "active",
    "cluster_title": "AI news digest",
    "core_facts": [
      "Digest of AI news: New Googlebooks, Gemini Intelligence for Android, Google circles SpaceX for orbital AI compute, Claude Code as Wall Street analyst, Amazon AI scoreboard, and more."
    ],
    "item_count": 1,
    "known_angles": [],
    "representative_items": [
      "item_bfb89d30b6a44b9c9978d61148575cb3"
    ]
  },
  {
    "cluster_status": "active",
    "cluster_title": "GPT-5.5 and GPT Image 2 available on Skywork",
    "core_facts": [
      "GPT-5.5 and GPT Image 2 are now available in Skywork, OpenAI's latest models."
    ],
    "item_count": 1,
    "known_angles": [],
    "representative_items": [
      "item_af5e63272e374d69a54a9d51f005599b"
    ]
  },
  {
    "cluster_status": "active",
    "cluster_title": "Possible Bun port from Zig to Rust",
    "core_facts": [
      "Simon Willison notes that Bun appears to be exploring a port from Zig to Rust based on a PORTING.md guide for coding agents."
    ],
    "item_count": 1,
    "known_angles": [],
    "representative_items": [
      "item_27881692a5774afdb2f65f66660d024f"
    ]
  },
  {
    "cluster_status": "active",
    "cluster_title": "Adialante launches mobile MRI for cancer screening",
    "core_facts": [
      "Adialante is making mobile MRI accessible, cutting costs to hundreds per scan and wait times to hours, aiming for annual cancer screening."
    ],
    "item_count": 1,
    "known_angles": [],
    "representative_items": [
      "item_8b5e5c4d6e4e48bb8fcf5beb69063bac"
    ]
  }
]
```

## 8. Source Profile Results

```json
{
  "disabled_for_llm_candidates": [],
  "high_candidates": [],
  "llm_total_tokens_by_source": {
    "socialmedia-ray-dalio-raydalio": 11723,
    "socialmedia-recraft-recraftai": 9658,
    "socialmedia-replit-replit": 19052,
    "socialmedia-runway-runwayml": 15667,
    "socialmedia-sam-altman-sama": 26553,
    "socialmedia-scott-wu-scottwu46": 5375,
    "socialmedia-simon-willison-simonw": 24434,
    "socialmedia-skywork-skywork-ai": 4750,
    "socialmedia-the-rundown-ai-therundownai": 21252,
    "socialmedia-vista8": 5314,
    "socialmedia-xai-xai": 2627,
    "socialmedia-y-combinator-ycombinator": 14833,
    "socialmedia-yann-lecun-ylecun": 0
  },
  "low_candidates": [],
  "pending_reviews_created": 0,
  "pending_reviews_created_all_types": 61,
  "reviews_suppressed_due_to_insufficient_data": 13,
  "sources_recomputed": 13,
  "sources_with_insufficient_data": [
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 11723,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-ray-dalio-raydalio",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 4,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 9658,
      "llm_yield_score": 2.5,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 2.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-recraft-recraftai",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 3,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 3,
      "llm_total_tokens": 19052,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-replit-replit",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 7,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 15667,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-runway-runwayml",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 3,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 1.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 26553,
      "llm_yield_score": 0.5,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 1.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-sam-altman-sama",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 5,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 5375,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-scott-wu-scottwu46",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 1,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 24434,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-simon-willison-simonw",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 5,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 4750,
      "llm_yield_score": 4.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-skywork-skywork-ai",
      "source_item_rate": 1.0,
      "source_material_rate": 1.0,
      "total_items": 1,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 21252,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-the-rundown-ai-therundownai",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 7,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 5314,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-vista8",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 2,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 2627,
      "llm_yield_score": 4.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-xai-xai",
      "source_item_rate": 1.0,
      "source_material_rate": 1.0,
      "total_items": 2,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 14833,
      "llm_yield_score": 3.375,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-y-combinator-ycombinator",
      "source_item_rate": 0.5,
      "source_material_rate": 0.5,
      "total_items": 9,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 0,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-yann-lecun-ylecun",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 1,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    }
  ],
  "top_sources_by_duplicate_rate": [
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 11723,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-ray-dalio-raydalio",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 4,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 9658,
      "llm_yield_score": 2.5,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 2.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-recraft-recraftai",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 3,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 3,
      "llm_total_tokens": 19052,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-replit-replit",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 7,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 15667,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-runway-runwayml",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 3,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 1.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 26553,
      "llm_yield_score": 0.5,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 1.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-sam-altman-sama",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 5,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 5375,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-scott-wu-scottwu46",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 1,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 24434,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-simon-willison-simonw",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 5,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 4750,
      "llm_yield_score": 4.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-skywork-skywork-ai",
      "source_item_rate": 1.0,
      "source_material_rate": 1.0,
      "total_items": 1,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 21252,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-the-rundown-ai-therundownai",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 7,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 5314,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-vista8",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 2,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    }
  ],
  "top_sources_by_incremental_value_avg": [
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 11723,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-ray-dalio-raydalio",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 4,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 9658,
      "llm_yield_score": 2.5,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 2.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-recraft-recraftai",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 3,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 24434,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-simon-willison-simonw",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 5,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 4750,
      "llm_yield_score": 4.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-skywork-skywork-ai",
      "source_item_rate": 1.0,
      "source_material_rate": 1.0,
      "total_items": 1,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 21252,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-the-rundown-ai-therundownai",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 7,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 2627,
      "llm_yield_score": 4.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-xai-xai",
      "source_item_rate": 1.0,
      "source_material_rate": 1.0,
      "total_items": 2,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 14833,
      "llm_yield_score": 3.375,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-y-combinator-ycombinator",
      "source_item_rate": 0.5,
      "source_material_rate": 0.5,
      "total_items": 9,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 1.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 26553,
      "llm_yield_score": 0.5,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 1.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-sam-altman-sama",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 5,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 3,
      "llm_total_tokens": 19052,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-replit-replit",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 7,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 15667,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-runway-runwayml",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 3,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    }
  ],
  "top_sources_by_llm_yield": [
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 4750,
      "llm_yield_score": 4.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-skywork-skywork-ai",
      "source_item_rate": 1.0,
      "source_material_rate": 1.0,
      "total_items": 1,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 2627,
      "llm_yield_score": 4.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-xai-xai",
      "source_item_rate": 1.0,
      "source_material_rate": 1.0,
      "total_items": 2,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 14833,
      "llm_yield_score": 3.375,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-y-combinator-ycombinator",
      "source_item_rate": 0.5,
      "source_material_rate": 0.5,
      "total_items": 9,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 11723,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-ray-dalio-raydalio",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 4,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 24434,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-simon-willison-simonw",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 5,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 21252,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-the-rundown-ai-therundownai",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 7,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 9658,
      "llm_yield_score": 2.5,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 2.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-recraft-recraftai",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 3,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 1.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 26553,
      "llm_yield_score": 0.5,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 1.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-sam-altman-sama",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 5,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 3,
      "llm_total_tokens": 19052,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-replit-replit",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 7,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 15667,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-runway-runwayml",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 3,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    }
  ],
  "top_sources_by_report_value_avg": [
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 11723,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-ray-dalio-raydalio",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 4,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 24434,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-simon-willison-simonw",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 5,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 4750,
      "llm_yield_score": 4.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-skywork-skywork-ai",
      "source_item_rate": 1.0,
      "source_material_rate": 1.0,
      "total_items": 1,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 21252,
      "llm_yield_score": 2.75,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-the-rundown-ai-therundownai",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 7,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 2627,
      "llm_yield_score": 4.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-xai-xai",
      "source_item_rate": 1.0,
      "source_material_rate": 1.0,
      "total_items": 2,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 0,
      "llm_total_tokens": 14833,
      "llm_yield_score": 3.375,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 3.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-y-combinator-ycombinator",
      "source_item_rate": 0.5,
      "source_material_rate": 0.5,
      "total_items": 9,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 3.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 9658,
      "llm_yield_score": 2.5,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 1.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 2.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-recraft-recraftai",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 3,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 1.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 26553,
      "llm_yield_score": 0.5,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 1.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-sam-altman-sama",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 5,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 3,
      "llm_total_tokens": 19052,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-replit-replit",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 7,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    },
    {
      "created_at": "2026-05-17T03:51:18.104682+00:00",
      "duplicate_rate": 0.0,
      "incremental_value_avg": 0.0,
      "llm_high_value_outputs": 0,
      "llm_priority": "new_source_under_evaluation",
      "llm_processed_items": 1,
      "llm_total_tokens": 15667,
      "llm_yield_score": 0.0,
      "near_duplicate_rate": 0.0,
      "new_event_rate": 0.0,
      "priority_suggestion": "new_source_under_evaluation",
      "report_value_avg": 0.0,
      "representative_item_rate": 0.0,
      "review_status": "none",
      "source_id": "socialmedia-runway-runwayml",
      "source_item_rate": 0.0,
      "source_material_rate": 0.0,
      "total_items": 3,
      "updated_at": "2026-05-17T03:51:18.104682+00:00"
    }
  ]
}
```

## 9. Token / Latency / Cache Summary

```json
[
  {
    "avg_candidates_per_call": null,
    "avg_latency_ms": 27015.1,
    "cache_hit_tokens": 6528,
    "cache_miss_tokens": 0,
    "calls": 7,
    "failed": 1,
    "input_tokens": 16315,
    "llm_call_count": 7,
    "operation_count": 7,
    "output_tokens": 17208,
    "p50_latency_ms": 26356,
    "p95_latency_ms": 37556,
    "parse_failures": 0,
    "rate_limit_errors": 0,
    "retry_count": 1,
    "skipped": 0,
    "success": 6,
    "task_type": "item_card",
    "total_tokens": 33523
  },
  {
    "avg_candidates_per_call": null,
    "avg_latency_ms": 10356.2,
    "cache_hit_tokens": 23808,
    "cache_miss_tokens": 0,
    "calls": 33,
    "failed": 0,
    "input_tokens": 57474,
    "llm_call_count": 33,
    "operation_count": 50,
    "output_tokens": 34149,
    "p50_latency_ms": 9562,
    "p95_latency_ms": 16324,
    "parse_failures": 0,
    "rate_limit_errors": 0,
    "retry_count": 0,
    "skipped": 17,
    "success": 33,
    "task_type": "item_relation",
    "total_tokens": 91623
  },
  {
    "avg_candidates_per_call": null,
    "avg_latency_ms": 6606.6,
    "cache_hit_tokens": 33280,
    "cache_miss_tokens": 0,
    "calls": 25,
    "failed": 0,
    "input_tokens": 49321,
    "llm_call_count": 25,
    "operation_count": 42,
    "output_tokens": 13447,
    "p50_latency_ms": 6131,
    "p95_latency_ms": 11196,
    "parse_failures": 0,
    "rate_limit_errors": 0,
    "retry_count": 0,
    "skipped": 17,
    "success": 25,
    "task_type": "item_cluster_relation",
    "total_tokens": 62768
  },
  {
    "avg_candidates_per_call": null,
    "avg_latency_ms": 11852.0,
    "cache_hit_tokens": 1536,
    "cache_miss_tokens": 0,
    "calls": 3,
    "failed": 0,
    "input_tokens": 3645,
    "llm_call_count": 3,
    "operation_count": 11,
    "output_tokens": 3202,
    "p50_latency_ms": 11712,
    "p95_latency_ms": 16421,
    "parse_failures": 0,
    "rate_limit_errors": 0,
    "retry_count": 0,
    "skipped": 8,
    "success": 3,
    "task_type": "cluster_card_patch",
    "total_tokens": 6847
  },
  {
    "avg_candidates_per_call": null,
    "avg_latency_ms": 0.0,
    "cache_hit_tokens": 0,
    "cache_miss_tokens": 0,
    "calls": 0,
    "failed": 0,
    "input_tokens": 0,
    "llm_call_count": 0,
    "operation_count": 0,
    "output_tokens": 0,
    "p50_latency_ms": 0,
    "p95_latency_ms": 0,
    "parse_failures": 0,
    "rate_limit_errors": 0,
    "retry_count": 0,
    "skipped": 0,
    "success": 0,
    "task_type": "cluster_card_rebuild",
    "total_tokens": 0
  },
  {
    "avg_candidates_per_call": null,
    "avg_latency_ms": 0.0,
    "cache_hit_tokens": 0,
    "cache_miss_tokens": 0,
    "calls": 0,
    "failed": 0,
    "input_tokens": 0,
    "llm_call_count": 0,
    "operation_count": 0,
    "output_tokens": 0,
    "p50_latency_ms": 0,
    "p95_latency_ms": 0,
    "parse_failures": 0,
    "rate_limit_errors": 0,
    "retry_count": 0,
    "skipped": 0,
    "success": 0,
    "task_type": "source_review",
    "total_tokens": 0
  },
  {
    "avg_candidates_per_call": null,
    "avg_latency_ms": 0.0,
    "cache_hit_tokens": 0,
    "cache_miss_tokens": 0,
    "calls": 0,
    "failed": 0,
    "input_tokens": 0,
    "llm_call_count": 0,
    "operation_count": 0,
    "output_tokens": 0,
    "p50_latency_ms": 0,
    "p95_latency_ms": 0,
    "parse_failures": 0,
    "rate_limit_errors": 0,
    "retry_count": 0,
    "skipped": 0,
    "success": 0,
    "task_type": "json_repair",
    "total_tokens": 0
  }
]
```

## 10. Concurrency Summary

```json
{
  "actual_calls": 68,
  "actual_tokens": 194761,
  "avg_latency_ms": 10758.5,
  "by_task": {
    "cluster_card_patch": {
      "avg_latency_ms": 11852.0,
      "cache_hit_tokens": 1536,
      "calls": 3,
      "concurrency": 3,
      "db_lock_errors": 0,
      "failed": 0,
      "p50_latency_ms": 11712,
      "p95_latency_ms": 16421,
      "parse_failures": 0,
      "rate_limit_errors": 0,
      "retry_count": 0,
      "success": 3,
      "task_type": "cluster_card_patch",
      "total_tokens": 6847
    },
    "cluster_card_rebuild": {
      "avg_latency_ms": 0.0,
      "cache_hit_tokens": 0,
      "calls": 0,
      "concurrency": 3,
      "db_lock_errors": 0,
      "failed": 0,
      "p50_latency_ms": 0,
      "p95_latency_ms": 0,
      "parse_failures": 0,
      "rate_limit_errors": 0,
      "retry_count": 0,
      "success": 0,
      "task_type": "cluster_card_rebuild",
      "total_tokens": 0
    },
    "item_card": {
      "avg_latency_ms": 27015.1,
      "cache_hit_tokens": 6528,
      "calls": 7,
      "concurrency": 3,
      "db_lock_errors": 0,
      "failed": 1,
      "p50_latency_ms": 26356,
      "p95_latency_ms": 37556,
      "parse_failures": 0,
      "rate_limit_errors": 0,
      "retry_count": 1,
      "success": 6,
      "task_type": "item_card",
      "total_tokens": 33523
    },
    "item_cluster_relation": {
      "avg_latency_ms": 6606.6,
      "cache_hit_tokens": 33280,
      "calls": 25,
      "concurrency": 3,
      "db_lock_errors": 0,
      "failed": 0,
      "p50_latency_ms": 6131,
      "p95_latency_ms": 11196,
      "parse_failures": 0,
      "rate_limit_errors": 0,
      "retry_count": 0,
      "success": 25,
      "task_type": "item_cluster_relation",
      "total_tokens": 62768
    },
    "item_relation": {
      "avg_latency_ms": 10356.2,
      "cache_hit_tokens": 23808,
      "calls": 33,
      "concurrency": 3,
      "db_lock_errors": 0,
      "failed": 0,
      "p50_latency_ms": 9562,
      "p95_latency_ms": 16324,
      "parse_failures": 0,
      "rate_limit_errors": 0,
      "retry_count": 0,
      "success": 33,
      "task_type": "item_relation",
      "total_tokens": 91623
    },
    "json_repair": {
      "avg_latency_ms": 0.0,
      "cache_hit_tokens": 0,
      "calls": 0,
      "concurrency": 3,
      "db_lock_errors": 0,
      "failed": 0,
      "p50_latency_ms": 0,
      "p95_latency_ms": 0,
      "parse_failures": 0,
      "rate_limit_errors": 0,
      "retry_count": 0,
      "success": 0,
      "task_type": "json_repair",
      "total_tokens": 0
    },
    "source_review": {
      "avg_latency_ms": 0.0,
      "cache_hit_tokens": 0,
      "calls": 0,
      "concurrency": 3,
      "db_lock_errors": 0,
      "failed": 0,
      "p50_latency_ms": 0,
      "p95_latency_ms": 0,
      "parse_failures": 0,
      "rate_limit_errors": 0,
      "retry_count": 0,
      "success": 0,
      "task_type": "source_review",
      "total_tokens": 0
    }
  },
  "cache_hit_rate": 0.3345,
  "cache_hit_tokens": 65152,
  "calls_per_sec": 0.1585,
  "db_lock_errors": 0,
  "duration_seconds": 429.014,
  "final_failures": 1,
  "max_concurrency": 3,
  "p50_latency_ms": 9150,
  "p95_latency_ms": 26356,
  "parse_failures": 0,
  "rate_limit_errors": 0,
  "repair_retry_count": 1,
  "tokens_per_sec": 453.97
}
```

## 11. Stage Budget Summary

```json
{
  "downstream_starved": false,
  "stage_budget_profile": "relation_heavy",
  "stages": {
    "cluster_card_patch": {
      "budget": 17500,
      "calls": 3,
      "consumed_tokens": 6847,
      "remaining_budget": 10653,
      "skipped": 8,
      "skipped_due_to_budget": 0
    },
    "item_card": {
      "budget": 80000,
      "calls": 7,
      "consumed_tokens": 33523,
      "remaining_budget": 46477,
      "skipped": 0,
      "skipped_due_to_budget": 0
    },
    "item_cluster_relation": {
      "budget": 60000,
      "calls": 25,
      "consumed_tokens": 62768,
      "remaining_budget": 0,
      "skipped": 17,
      "skipped_due_to_budget": 17
    },
    "item_relation": {
      "budget": 85000,
      "calls": 33,
      "consumed_tokens": 91623,
      "remaining_budget": 0,
      "skipped": 17,
      "skipped_due_to_budget": 17
    },
    "source_profile": {
      "budget": 7500,
      "calls": 0,
      "consumed_tokens": 0,
      "remaining_budget": 7500,
      "skipped": 0,
      "skipped_due_to_budget": 0
    }
  },
  "total_token_budget": 250000
}
```

## 12. Errors / Fallbacks / Retries

```json
{
  "db_lock_errors": 0,
  "final_failures": 1,
  "llm_parse_failures": 0,
  "repair_retry_count": 1,
  "review_queue_entries_due_to_failure": 34,
  "skipped_due_to_max_calls": false,
  "skipped_due_to_missing_card": 0,
  "skipped_due_to_no_candidate": 0,
  "skipped_due_to_token_budget": false
}
```

## 13. Prompt Iteration Notes

```json
[
  {
    "changes": [
      "source scope filtering",
      "sample modes",
      "operation_count versus llm_call_count report split",
      "concurrency summary"
    ],
    "concurrency": 3,
    "iteration": "phase1_2_current",
    "max_calls": 120,
    "max_items": 50,
    "notes": "No enum expansion; prompt JSON contracts remain stable.",
    "sample_mode": "event_hotspots"
  }
]
```

## 14. Manual Review Suggestions

```json
{
  "high_uncertain": [],
  "possible_miscluster": [],
  "possible_missplit": [
    {
      "cluster_id": "cluster_f8be7c6e426b4709aee0e96aa88ef900",
      "confidence": 0.6,
      "created_at": "2026-05-17T03:49:20.492047+00:00",
      "decision_source": "llm",
      "evidence_json": "[\"The item uses 'our next model' indicating a future release from the same entity as Recraft V4.\", \"The entities are similar ('Powered') and the context is about model improvement.\"]",
      "follow_up_event": 1,
      "id": 3,
      "incremental_value": 1,
      "input_fingerprint": "6fd68440cb7dfe1d370f201c695b43db39de4a76f11fce23bd68ee2ca11763ba",
      "item_id": "item_c712ff5cef3e421db70f5146d235c11c",
      "llm_call_id": 72,
      "model": "deepseek-v4-flash",
      "new_angles_json": "[\"user feedback request for next model version\"]",
      "new_facts_json": "[]",
      "primary_relation": "follow_up",
      "prompt_version": "item_cluster_relation_v1",
      "reason": "The new item is a social media post asking for suggestions on what to improve in the next model, which is a follow-up to the Recraft V4 release cluster, as it seeks input for a future iteration.",
      "report_value": 1,
      "same_event": 0,
      "same_topic": 1,
      "schema_version": "semantic_v1",
      "secondary_roles_json": "[\"user_feedback\"]",
      "should_notify": 0,
      "should_update_cluster_card": 0,
      "updated_at": "2026-05-17T03:49:20.492047+00:00"
    }
  ],
  "top_review_items_or_clusters": [
    {
      "cluster_id": "cluster_f8be7c6e426b4709aee0e96aa88ef900",
      "confidence": 0.6,
      "created_at": "2026-05-17T03:49:20.492047+00:00",
      "decision_source": "llm",
      "evidence_json": "[\"The item uses 'our next model' indicating a future release from the same entity as Recraft V4.\", \"The entities are similar ('Powered') and the context is about model improvement.\"]",
      "follow_up_event": 1,
      "id": 3,
      "incremental_value": 1,
      "input_fingerprint": "6fd68440cb7dfe1d370f201c695b43db39de4a76f11fce23bd68ee2ca11763ba",
      "item_id": "item_c712ff5cef3e421db70f5146d235c11c",
      "llm_call_id": 72,
      "model": "deepseek-v4-flash",
      "new_angles_json": "[\"user feedback request for next model version\"]",
      "new_facts_json": "[]",
      "primary_relation": "follow_up",
      "prompt_version": "item_cluster_relation_v1",
      "reason": "The new item is a social media post asking for suggestions on what to improve in the next model, which is a follow-up to the Recraft V4 release cluster, as it seeks input for a future iteration.",
      "report_value": 1,
      "same_event": 0,
      "same_topic": 1,
      "schema_version": "semantic_v1",
      "secondary_roles_json": "[\"user_feedback\"]",
      "should_notify": 0,
      "should_update_cluster_card": 0,
      "updated_at": "2026-05-17T03:49:20.492047+00:00"
    }
  ]
}
```

## 14. Readiness Assessment

```json
{
  "cluster_signal_count": 11,
  "reasons": [
    "Use dry-run reports for manual review before write-real-db.",
    "Candidate recall is still lexical/entity/time/source hybrid, not vector-indexed.",
    "1 LLM failures observed in this run."
  ],
  "write_real_db_recommended_now": false
}
```

## 15. Readiness Assessment

```json
{
  "cluster_signal_count": 11,
  "reasons": [
    "Use dry-run reports for manual review before write-real-db.",
    "Candidate recall is still lexical/entity/time/source hybrid, not vector-indexed.",
    "1 LLM failures observed in this run."
  ],
  "write_real_db_recommended_now": false
}
```

## 16. Recommendations

- Review uncertain relations and tune prompts with real examples.
- Add vector indexes for item_cards and cluster_cards before larger runs.
- Keep primary relation enum unchanged for now; it covered Phase 1.1 control flow.
- Collect more source_signals before trusting source_profile priority suggestions.
- Run a larger dry-run before any write-real-db semantic pass.
